在 src/assets/添加icon-clickable.png

在 src/components/ 替换video-player.scss,video-player.tsx